Kaydee: Dissociation Constant (KD) Fitting



#### TERMINOLOGY
DT:    data type: XY or XYD
NP:    number of data points, e.g., 9
PC:    protein concentration, e.g. 1.00 uM
X:     ligand concentration at one data point; e.g., 0.20 uM
Y:     measurement change at one data point in an arbitrary unit, e.g., 10.00 degrees             
D:     variation (standard deviation) of y at one data point; the weight of y
Ymax:  fitted maximum of y
KD:    fitted dissociation constant, e.g. 1.00 uM
Ymax0: starting maximum of y for fitting
KD0:   starting dissociation constant for fitting 
YmaxF: only used in 1xydf mode; set it to a positive value to fix Ymax during fitting
KDF:   only used in 1xydf mode; set it to a positive value to fix KD during fitting 
Nip:   number of interpolated points between two experimental points, e.g., 20



#### MODES
1xy:   one binding site, without standard deviations in y values
       IN:  kaydee_one_site_xy.par kaydee_one_site_xy.kdi
       OUT: kaydee_one_site_xy.log kaydee_one_site_xy.kdo

1xyd:  one binding site, with standard deviations in y values
       If the SDs of all the data points in the .kdi file are the same positive value, mode 1xyd is equivalent to mode 1xy.
       IN:  kaydee_one_site_xyd.par kaydee_one_site_xyd.kdi
       OUT: kaydee_one_site_xyd.log kaydee_one_site_xyd.kdo   

1xydf: one binding site, with standard deviations in y values;
       In the .par file, use YmaxF to fix Ymax and KDF to fix KD during fitting. Fixing both causes failure during fitting.
       If the SDs of all the data points in the .kdi file are the same positive value, mode 1xydf is equivalent to mode 1xyf, therefore not implemented.
       IN:  kaydee_one_site_xydf.par kaydee_one_site_xydf.kdi
       OUT: kaydee_one_site_xydf.log kaydee_one_site_xydf.kdo  

All the input (.par and .kdi) and output (.log and .kdo) files are plain text files.
The .kdo file can be read into Gnuplot for graphing using the script in the examples directory.



#### COMPILATION
# You need to have a c++ compiler and boost library installed first.
# If your boost library is installed in a directory different from the one in the Makefile,
# you need to modify the following line in the Makefile manually.
# CPPFLAGS = -std=c++11  -I/usr/local/boost_1_79_0/
# Tested platforms: Red Hat Enterprise Linux 7.5 (g++: 4.8.5; boost: 1.79.0)
#                   MacOS 10.13.4 (xcode: 9.4.1/c++: 4.2.1; boost: 1.79.0)
make clean
make



#### RUN
./kaydee -parFile kaydee.par > kaydee.log

# e.g.,
./kaydee -parFile kaydee_one_site_xy.par > kaydee_one_site_xy.log
./kaydee -parFile kaydee_one_site_xyd.par > kaydee_one_site_xyd.log
./kaydee -parFile kaydee_one_site_xydf.par > kaydee_one_site_xydf.log