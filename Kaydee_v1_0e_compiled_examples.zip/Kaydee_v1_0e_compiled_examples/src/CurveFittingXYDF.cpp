/*
Curve Fitting XYDF
using the generic Levenberg-Marquardt Minimization
 */

#include "LevenbergMarquardtMinimization.h"
#include "CurveFittingXYDF.h"

typedef struct {
    const double* t;
    const double* y;
    const double* dy;
    double (*f)(const double t, const double* par);
} lmcurve_tydf_data_struct;


typedef struct {
    const double* t;
    const double* y;
    const double* dy;
    const double *const PC;
    const double *const YmaxF;
    const double *const KDF;
    double (*f_xydf4)(const double t, const double* par, const double PC, const double YmaxF, const double KDF);
} lmcurve_tydf_data_struct4;


void lmcurve_tydf_evaluate(
    const double* par, const int m_dat, const void* data, double* fvec,
    int* info)
{
    lmcurve_tydf_data_struct* D = (lmcurve_tydf_data_struct*)data;
    int i;
    for (i = 0; i < m_dat; i++)
        fvec[i] = ( D->y[i] - D->f(D->t[i], par) ) / D->dy[i];
}

void lmcurve_tydf_evaluate4(
    const double* par, const int m_dat, const void* data, double* fvec,
    int* info)
{
    lmcurve_tydf_data_struct4* D = (lmcurve_tydf_data_struct4*)data;
    int i;
    for (i = 0; i < m_dat; i++)
        fvec[i] = ( D->y[i] - D->f_xydf4(D->t[i], par, D->PC[i], D->YmaxF[i], D->KDF[i]) ) / D->dy[i];
}


void lmcurve_tydf(
    const int n_par, double* par, const int m_dat,
    const double* t, const double* y, const double* dy,
    double (*f)(const double t, const double* par),
    const lm_control_struct* control, lm_status_struct* status)
{
    lmcurve_tydf_data_struct data = { t, y, dy, f };

    //lmmin(n_par, par, m_dat, (const void*)&data, lmcurve_tyd_evaluate, control, status);
    lmmin(n_par, par, m_dat, NULL, (const void*)&data, lmcurve_tydf_evaluate, control, status); // maybe not right to add NULL, SZC

    //lmmin(n_par, par, m_dat, static_cast<char*>(const void*)&data, lmcurve_tyd_evaluate, control, status);
}

extern "C" void lmcurve_tydf4(
    const int n_par, double* par, const int m_dat,
    const double* t, const double* y, const double* dy, const double* PC, const double* YmaxF,const double* KDF,
    double (*f_xydf4)(const double t, const double* par, const double PC, const double YmaxF,const double KDF),
    const lm_control_struct* control, lm_status_struct* status)
{
    lmcurve_tydf_data_struct4 data = { t, y, dy, PC, YmaxF, KDF, f_xydf4 };
    
    //lmmin(n_par, par, m_dat, (const void*)&data, lmcurve_tyd_evaluate, control, status);
    lmmin(n_par, par, m_dat, NULL, (const void*)&data, lmcurve_tydf_evaluate4, control, status); // maybe not right to add NULL, SZC

    //lmmin(n_par, par, m_dat, static_cast<char*>(const void*)&data, lmcurve_tyd_evaluate, control, status);
}
