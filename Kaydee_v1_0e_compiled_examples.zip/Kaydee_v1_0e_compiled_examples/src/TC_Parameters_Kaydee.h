#pragma once

#include <vector>
#include <string>


class Parameters
{

public:
    // unparameterized constructor
    Parameters();
    // parameterized constructor (special function)
    Parameters(std::vector<std::string> argList);
    // destructor
    ~Parameters();
    
    // the following variables are parameters read from the command line or a parameter file.
    std::string mode;          // 1wov; 1wv
    
    //std::string kaydee input file in .kdi format;
    std::string inp_file_kdi;  // inp_data.kdi
    
    //std::string kaydee output file in .kdo format;
    std::string out_file_kdo;  // out_data.kdo
         
    //std::string DT;            // data type: XY or XYD
    int NP;                    // number of data points
    double PC;                 // protein concentration
    
    double Ymax0;              // starting maximum of y for fitting
    double KD0;                // starting dissociation constant for fitting
    double YmaxF;              // used in 1xydf mode; set it to a positive value to fix it during fitting
    double KDF;                // used in 1xydf mode; set it to a positive value to fix it during fitting
    
    int Nip;                   // number of interpolated points between two experimental points
    
    void checkParameters();        
    
private:

    void readParameters(std::vector<std::string> argList);
    
    void parseParameterFile(const std::string tiltcom);
    void parseCommandLine(std::vector<std::string> argList);
    void storeParameterNamesAndValues(std::string parName, std::string parValue);    
    
    
    // the following variables are FLAGs
    int mode_F;
    
    //std::string kaydee input file in .kdi format;
    int inp_file_kdi_F;
    
    //std::string kaydee output file in .kdo format;
    int out_file_kdo_F;

    //int DT_F;
    int NP_F;
    int PC_F;
    
    int Ymax0_F;
    int KD0_F;
    int YmaxF_F;
    int KDF_F;
    
    int Nip_F;
    
 
};
