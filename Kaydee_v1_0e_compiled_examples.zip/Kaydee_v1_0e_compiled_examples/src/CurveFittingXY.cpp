/*
Curve Fitting XY
using the generic Levenberg-Marquardt Minimization
 */

#include "LevenbergMarquardtMinimization.h"
#include "CurveFittingXY.h"

typedef struct {
    const double *const t;
    const double *const y;
    double (*const g) (const double t, const double *par);
} lmcurve_data_struct;


typedef struct {
    const double *const t;
    const double *const y;
    const double *const PC;
    double (*const g_xy3) (const double t, const double *par, const double PC);
} lmcurve_data_struct3;


void lmcurve_evaluate(
    const double *const par, const int m_dat, const void *const data,
    double *const fvec, int *const info)
{
    for (int i = 0; i < m_dat; i++ )
        fvec[i] =
            ((lmcurve_data_struct*)data)->y[i] -
            ((lmcurve_data_struct*)data)->g( ((lmcurve_data_struct*)data)->t[i], par);
}


void lmcurve_evaluate3(
    const double *const par, const int m_dat, const void *const data,
    double *const fvec, int *const info)
{
    for (int i = 0; i < m_dat; i++ )
        fvec[i] =
            ((lmcurve_data_struct3*)data)->y[i] -
            ((lmcurve_data_struct3*)data)->g_xy3( ((lmcurve_data_struct3*)data)->t[i], par, ((lmcurve_data_struct3*)data)->PC[i]);
}


// To call the C function "lmcurve" from C++, we need to add (extern "C") at the beginning
extern "C" void lmcurve(
    const int n_par, double *const par, const int m_dat,
    const double *const t, const double *const y,
    double (*const g)(const double t, const double *const par),
    const lm_control_struct *const control, lm_status_struct *const status)
{
    lmcurve_data_struct data = {t, y, g};
    lmmin(n_par, par, m_dat, NULL, (const void *const) &data,
          lmcurve_evaluate, control, status);
}


extern "C" void lmcurve3(
    const int n_par, double *const par, const int m_dat,
    const double *const t, const double *const y, const double* PC,
    double (*const g_xy3)(const double t, const double *const par, const double PC),
    const lm_control_struct *const control, lm_status_struct *const status)
{
    lmcurve_data_struct3 data = {t, y, PC, g_xy3};
    lmmin(n_par, par, m_dat, NULL, (const void *const) &data,
          lmcurve_evaluate3, control, status);
}
