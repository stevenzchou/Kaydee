/*
Square Matrix Inversion
 */

void lm_invert(double *const A, const int n, int *const P, double *const ws,
               double *const IA, int*const failure);
