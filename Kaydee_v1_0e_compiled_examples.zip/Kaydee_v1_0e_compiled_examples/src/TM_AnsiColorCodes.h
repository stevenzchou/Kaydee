// TEMPLATE MACRO:         TM_AnsiColorCodes.h
// REFERENCES:             https://stackoverflow.com/questions/2616906/how-do-i-output-coloured-text-to-a-linux-terminal
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE MACRO?    

** Put TM_AnsiColorCodes.h in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TM_AnsiColorCodes.h"

** After defining 'inputFileName' and 'inputFileName', add ---
   std::cout << "\nThe source file (" 
   << FGCBLU<<FABOLD<<BGCGRY<<__FILE__<<RESET << ") was compiled with C++"
   << FGCGRN<<FABOLD<<__cplusplus<<RESET
   << " on " << FGCMAG<<FABOLD<<__DATE__<<RESET 
   << " at " << FGCCYN<<FABOLD<<__TIME__<<RESET << ".\n\n"; 
*/



////////////////////////////////////////////////////
#ifndef TM_AnsiColorCodes_h
#define TM_AnsiColorCodes_h

//// foreground color      [FGC]	      
#define FGCRED "\033[0;31m"
#define FGCGRN "\033[0;32m"
#define FGCYEL "\033[0;33m"
#define FGCBLU "\033[0;34m"
#define FGCMAG "\033[0;35m"
#define FGCCYN "\033[0;36m"
#define FGCGRY "\033[0;37m"

//// background color      [BGC]
#define BGCRED "\033[41m"
#define BGCGRN "\033[42m"
#define BGCYEL "\033[43m"
#define BGCBLU "\033[44m"
#define BGCMAG "\033[45m"
#define BGCCYN "\033[46m"
#define BGCGRY "\033[47m"

//// format attribute      [FA]
#define FABOLD "\033[1m"     
#define FAUNDL "\033[4m"

//// reset
#define RESET  "\033[0m"
 
#endif // TM_AnsiColorCodes_h
















