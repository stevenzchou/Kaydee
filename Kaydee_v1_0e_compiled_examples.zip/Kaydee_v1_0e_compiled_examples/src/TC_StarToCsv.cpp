// TEMPLATE CLASS:         TC_StarToCsv.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_StarToCsv.h and TC_StarToCsv.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_StarToCsv.h"

** After defining 'inputFileName' and 'outputFileName', add ---
   StarToCsv s2c;
   s2c.star2csv(inputFileName, outputFileName);  
*/

#include "TC_StarToCsv.h"

// ofstream: Stream class to write on files
// ifstream: Stream class to read from files
// fstream: Stream class to both read and write from/to files.

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <vector>
// vector class; including std::vector; It's a kind of containers.

#include <string>
// String class; string object where the extracted line is stored.

#include <sstream>
// string stream ; input string stream; output string stream

//#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 


StarToCsv::StarToCsv() 
{
  int x = 1;
  // The constructor can NOT be empty
}

StarToCsv::~StarToCsv() 
{
  // The destructor can be empty.
}


void StarToCsv::star2csv(std::string inputFileName, std::string outputFileName) 
{

    // progress
    std::cout << "working on: " << inputFileName << "\n";  
     
    //// read
    std::ifstream inputFile (inputFileName, std::ifstream::in);
    std::string lineInInputFile;
    if ( inputFile.is_open() )
    {
      int lineId = 0;
      
      int micNameCol = 0;
      int coordXCol = 0;  
      int coordYCol = 0;
      int tubeIdCol = 0;
      int trackLengthCol = 0;      
      int magCol = 0;
      int detPixSizeCol = 0;  
      int twistCol = 0;   
  
                    
      std::string micNameCurr = "";
      std::string micNamePrev = "";
      int tubeIdCurr = 0;            
      int tubeIdPrev = 0;
      float pixSizeCurr = 0.0;
      float pixSizePrev = 0.0;
      float trackLengthCurr = 0.0;
      float trackLengthPrev = 0.0;      
      float riseCurr = 0.0;
      float risePrev = 0.0;             

      
      std::ofstream outputFile(outputFileName, std::ofstream::out); // clean and write
      //std::ofstream outputFile(outputFileName, std::ofstream::out | std::ofstream::app);// append  
	      
      while ( std::getline(inputFile, lineInInputFile) )
      {
        
	lineId = lineId +1;
	
	
	//// split lines      
        std::vector<std::string> vectorContainingTheSplitLine;
          
        // use boost::split: any type of space, any number of space, any character
        //boost::split(vectorContainingTheSplitLine, lineInInputFile, boost::is_any_of("\t "),boost::token_compress_on );
            
              
        // use stream operator: any type of space, any number of space
        std::stringstream ss(lineInInputFile);
        while (ss.good()) {
              std::string word;
              ss >> word;
              vectorContainingTheSplitLine.push_back(word);
        }// while
              
              
        /*
        // use getline: any one character
        std::stringstream ss(lineInInputFile);
        while (ss.good()) {
                 std::string word;
                 getline(ss,word,'s');
                 vectorContainingTheSplitLine.push_back(word);
        }
        */
            


        //std::cout << "* size of the vector: " << vectorContainingTheSplitLine.size() << "\n"; 
        // std::size_t usually works better than int when indexing C++ containers, such as std::vectors, std::string.
        //for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++)
            //std::cout << vectorContainingTheSplitLine[i] << "\n";
	
	
	//// get column IDs    
        if ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnMicrographName" ) {
            micNameCol = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
	} else if ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnCoordinateX" ) {
            coordXCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnCoordinateY" ) {
            coordYCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 	
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnMagnification" ) {
            magCol     = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnDetectorPixelSize" ) {
            detPixSizeCol = std::stoi(vectorContainingTheSplitLine[1].substr(1));    
        } else if ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnHelicalTubeID" ) {
            tubeIdCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnHelicalTrackLength" ) {
            trackLengthCol = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlntwist" ) {
            twistCol   = std::stoi(vectorContainingTheSplitLine[1].substr(1)); 
	}
        
	//std::cout <<  micNameCol << " " << tubeIdCol << " "  << " " << trackLengthCol << " " <<  magCol << " " << detPixSizeCol << "\n";
	
	//// work on data lines 
	if (vectorContainingTheSplitLine.size() > 3) {	
	
	  micNameCurr = vectorContainingTheSplitLine[micNameCol-1];	
	  tubeIdCurr = std::stod(vectorContainingTheSplitLine[tubeIdCol-1]);
	  pixSizeCurr =  (double) (std::stod(vectorContainingTheSplitLine[detPixSizeCol-1])/std::stod(vectorContainingTheSplitLine[magCol-1])*10000); // um => A
	  if (pixSizeCurr != pixSizePrev && pixSizePrev != 0.0){
	      std::cout << "ERROR: different pixel sizes in the input file at lines: " << lineId-1 << " " << lineId << "\n"; exit(1);
	  } else {pixSizePrev = pixSizeCurr;}
	  trackLengthCurr = std::stod(vectorContainingTheSplitLine[trackLengthCol-1]);
	}

	
        if ( (vectorContainingTheSplitLine.size() > 3) && ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev ) ) {
	   micNamePrev     = micNameCurr;
	   tubeIdPrev      = tubeIdCurr;
           trackLengthPrev = trackLengthCurr;

        } else if ( vectorContainingTheSplitLine.size() > 3 && micNameCurr == micNamePrev && tubeIdCurr == tubeIdPrev  ){
           riseCurr = (double) ( (trackLengthCurr - trackLengthPrev)*pixSizeCurr );  	     
           
	   for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++) { 
	     if (i == micNameCol-1 || i == coordXCol-1 || i == coordYCol-1  || i == tubeIdCol-1 || i == trackLengthCol-1  || i == twistCol-1) {
	       outputFile << vectorContainingTheSplitLine[i] << ",";
	     }
	   }	   
	   outputFile << riseCurr << ",micName|coordX|coordY|helixID|trackLength|twist|rise \n";
	   
	   micNamePrev     = micNameCurr;
	   tubeIdPrev      = tubeIdCurr;
           trackLengthPrev = trackLengthCurr;	   
	   
        }  


      } // while 


      outputFile.close();
      inputFile.close();
    } else {
      //std::cout << "Cannot open input file: " << inputFileName << "\n";
    } // if ( inputFile.is_open() )
    
    //return 0;
   
    

}; 

 
