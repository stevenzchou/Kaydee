// TO COMPILE: g++ -std=c++11 -c TC_Parameters.cpp -o TC_Parameters.o
// TO LINK   :  see the 'Makefile'


#include "TC_Parameters_Kaydee.h"

#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>

#include <cstdlib>
//C Standard General Utilities Library; exit; 

#include <sstream>
// string stream ; input string stream; output string stream

//#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cctype>
// Character handling functions; including isspace(int c)



Parameters::Parameters()
{
}


Parameters::~Parameters()
{
}

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
// local function:                    declared and defined in .cpp (but not in .h) and called (from the same .cpp)
// Inside class member function:      declared and defined in (.h or main.cpp) and called after creating an object
// outside class member function:     declared in (.h), defined in (.cpp) and called after creating an object


void Parameters::storeParameterNamesAndValues(std::string parName, std::string parValue)
{
  if      ( parName == "parFile"                     ) {} // parameter file
  else if ( parName == "mode"                        ) {mode          = parValue; mode_F         = 1;}
  else if ( parName == "inp_file_kdi"                ) {inp_file_kdi  = parValue; inp_file_kdi_F = 1;}
  else if ( parName == "out_file_kdo"                ) {out_file_kdo  = parValue; out_file_kdo_F = 1;}
//else if ( parName == "DT"                          ) {DT            = parValue; DT_F           = 1;}
  else if ( parName == "NP"                          ) {NP            = std::stoi(parValue); NP_F           = 1;}
  else if ( parName == "PC"                          ) {PC            = std::stod(parValue); PC_F           = 1;}
  else if ( parName == "Ymax0"                       ) {Ymax0         = std::stod(parValue); Ymax0_F        = 1;}
  else if ( parName == "KD0"                         ) {KD0           = std::stod(parValue); KD0_F          = 1;}
  else if ( parName == "YmaxF"                       ) {YmaxF         = std::stod(parValue); YmaxF_F        = 1;}
  else if ( parName == "KDF"                         ) {KDF           = std::stod(parValue); KDF_F          = 1;}
  else if ( parName == "Nip"                         ) {Nip           = std::stoi(parValue); Nip_F          = 1;}
  else { std::cout << "IGNORED PARAMETER <NAME> AND <VALUE>: <" << parName << "> <" << parValue << ">\n";}
}


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
void Parameters::parseCommandLine(std::vector<std::string> argList)
{
  std::string parName;
  std::string parValue; 
  for(std::vector<std::string>::iterator it=argList.begin(); it!=argList.end();it++)
  {
    parName=*it;
    std::vector<std::string>::iterator nextArgument = it+1;

    if (parName.substr(0,1) == "-" && nextArgument != argList.end())
    {
      parName.erase(0,1); //erase "-" at the beginning of of line in 
      parValue = *nextArgument;
      //std::cout <<  "parName " <<  parName << " parValue " << parValue << "\n";
      storeParameterNamesAndValues(parName, parValue);
      it++; // every other argument   
    }
  }
}


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
void Parameters::parseParameterFile(const std::string parameterFileName)
{
  std::ifstream parameterFileS(parameterFileName.c_str());
  if (!parameterFileS){ std::cout << "FAIL to open: " << parameterFileName << "\n"; return;}

  std::string lineInParameterFile;
  std::string parName;
  std::string parValue;	 
  while(std::getline(parameterFileS, lineInParameterFile))
  {
    // lineInParameterFile: -voltage  300  kV  # /// Accelerating Voltage (in KiloVolts)    
    //std::cout << lineInInputFile << "\n";

    std::vector<std::string> vectorContainingTheSplitLine;
      
    // use boost::split: any type of space, any number of space, any character
    //boost::split(vectorContainingTheSplitLine, lineInParameterFile, boost::is_any_of("\t "),boost::token_compress_on );
        
          
    // use stream operator: any type of space, any number of space
    std::stringstream ss(lineInParameterFile);
    while (ss.good()) {
          std::string word;
          ss >> word;
          vectorContainingTheSplitLine.push_back(word);
    }// while
          
          
    /*
    // use getline: any one character
    std::stringstream ss(lineInParameterFile);
    while (ss.good()) {
             std::string word;
             getline(ss,word,'s');
             vectorContainingTheSplitLine.push_back(word);
    }
    */

    //std::cout << vectorContainingTheSplitLine[i] << "\n";
    parName = vectorContainingTheSplitLine[0];
    //std::cout <<  "parName" << parName.substr(0,2) << "\n";		    
    if (parName.substr(0,1) == "_")
    {
      parName.erase(0,1); //erase "-" at the beginning of of line in 
      parValue = vectorContainingTheSplitLine[1];
      //std::cout <<  "parName " <<  parName << " parValue " << parValue << "\n";
      storeParameterNamesAndValues(parName, parValue);
    } // if 
  } // while
} // void 

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100  

Parameters::Parameters(std::vector<std::string> argList)
{
    
  //if (argList.size() % 2 != 0) { std::cout << "ERROR: At least, one parameter was specified incorrectly.\n"; exit(EXIT_FAILURE);}
  
  // Check if .par file is among the parameters and if so parse it first.
  // The command line parameters have higher priority than those in the par file.
  // The command line parameters can change any parameters set by .par file.
  int parFileExists = 0; // for checking the existance of .par file
  for(std::vector<std::string>::iterator it=argList.begin(); it!=argList.end(); it++)
  {
    if((*it)=="-parFile")
    {
      std::vector<std::string>::iterator nextArgument = it + 1;
      std::cout << "Parsing the parameter file: " << *nextArgument << "\n";
      parseParameterFile( (*nextArgument) );
      parFileExists = 1;
    } // if
  } // for
  
  if (parFileExists == 1){ 
  std::cout << "Parsing the command line. \n";
  //std::cout << "Command line values overwrite their corresponding parts in the parameter file.\n";
  } else { std::cout << "Parsing the command line. \n";}
  
  parseCommandLine(argList);

} // Parameters::Parameters(std::vector<std::string> argList)

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//void Parameters::checkParameters(std::string mode)
void Parameters::checkParameters()
{
  std::cout << "Checking parameters : \n";
  std::cout.precision(7);
    if(mode_F                        <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    mode                   \n"; return;}
        	                       else {std::cout<<"mode                         : "<<mode              	      << "\n";}
				  
    if(inp_file_kdi_F                <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    inp_file_kdi	          \n"; return;}
                                   else {std::cout<<"inp_file_kdi                 : "<<inp_file_kdi	              << "\n";}

    if(out_file_kdo_F                <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    out_file_kdo           \n"; return;}
                                   else {std::cout<<"out_file_kdo                 : "<<out_file_kdo               << "\n";}
    
    //if(DT_F                          <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    DT                     \n"; return;}
    //                               else {std::cout<<"DT                           : "<<DT                         << "\n";}

    if(NP_F                          <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    NP                     \n"; return;}
                                   else {std::cout<<"NP                           : "<<NP                         << "\n";}
    
    if(PC_F                          <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    PC                     \n"; return;}
                                   else {std::cout<<"PC                           : "<<PC                         << "\n";}
    
    if(Ymax0_F                       <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    Ymax0                  \n"; return;}
                                   else {std::cout<<"Ymax0                        : "<<Ymax0                      << "\n";}
    
    if(KD0_F                         <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    KD0                    \n"; return;}
                                   else {std::cout<<"KD0                          : "<<KD0                        << "\n";}
    
    if(YmaxF_F                       <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    YmaxF                  \n"; return;}
                                   else {std::cout<<"YmaxF                        : "<<YmaxF                      << "\n";}

    if(KDF_F                         <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    KDF                    \n"; return;}
                                   else {std::cout<<"KDF                          : "<<KDF                        << "\n";}
    

    if(Nip_F                         <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    Nip                    \n"; return;}
                                   else {std::cout<<"Nip                          : "<<Nip                        << "\n";}
    

} // void Parameters::checkParameters(std::string mode)

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
