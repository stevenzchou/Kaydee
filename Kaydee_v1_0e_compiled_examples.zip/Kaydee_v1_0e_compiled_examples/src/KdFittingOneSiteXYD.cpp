// TEMPLATE CLASS:         n/a
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>



#include "CurveFittingXYD.h"
#include <stdio.h>
#include <math.h>

#include "TC_Parameters_Kaydee.h"
#include "KdFittingOneSiteXYD.h"

// ofstream: Stream class to write on files
// ifstream: Stream class to read from files
// fstream: Stream class to both read and write from/to files.
#include <iomanip>
// IO Manipulators; e.g., std::setw(6)

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <sstream>
//String stream; std::stringstream;

#include <vector>
// vector class; including std::vector; It's a kind of containers.

#include <string>
// String class; string object where the extracted line is stored.

//#include </Applications/boost/boost_1_55_0/boost/algorithm/string.hpp>

#include <sstream>
// string stream ; input string stream; output string stream

//#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 
 

#include <cmath>
KdFittingOneSiteXYD::KdFittingOneSiteXYD(Parameters& parO)
{
  iParO = parO;
  int x = 1;
  // The constructor can NOT be empty
}

KdFittingOneSiteXYD::~KdFittingOneSiteXYD()
{
  // The destructor can be empty.
}


// To call the C function "f" from C++, we need to add (extern "C") at the beginning. For details, see the following website.
//https://isocpp.org/wiki/faq/mixing-c-and-cpp#:~:text=Just%20declare%20the%20C%20function,int)%3B%20%2F%2F%20one%20way
// f is not used; f4 is used instead.
extern "C" double f_xyd (const double t, const double *p);
double f_xyd (const double t, const double *p)
{
    /*
     p[0]: ymax
     p[1]: KD
     y = (((KD+P0+x)-((KD+P0+x)^2-4*P0*x)^0.5)/2)*ymax/P0
     */
    double PC = 0.1  ; // protein starting concentration in unit of uM
    return (( (p[1]+PC+t) - sqrt( (p[1]+PC+t)*(p[1]+PC+t) - 4*PC*t ) )/2)*p[0]/PC;
}

extern "C" double f_xyd4 (const double t, const double *p, const double PC);
double f_xyd4 ( const double t, const double *p , const double PC)
{
    /*
     p[0]: ymax
     p[1]: KD
     y = (((KD+P0+x)-((KD+P0+x)^2-4*P0*x)^0.5)/2)*ymax/P0
     */
    return (( (p[1]+PC+t) - sqrt( (p[1]+PC+t)*(p[1]+PC+t) - 4*PC*t ) )/2)*p[0]/PC;
}

extern "C" double f_xyd4out (double Ymax, double KD, double PC, double xout);
double f_xyd4out (double Ymax, double KD, double PC, double xout)
{
    /*
     p[0]: Ymax
     p[1]: KD
     y = (((KD+P0+x)-((KD+P0+x)^2-4*P0*x)^0.5)/2)*ymax/P0
     */
    return (( (KD+PC+xout) - sqrt( (KD+PC+xout)*(KD+PC+xout) - 4*PC*xout ) )/2)*Ymax/PC;
}

void KdFittingOneSiteXYD::kdFittingOneSiteXYD()
{
  //std::cout.precision(17);
  
  //std::cout.precision (6);
  //std::fixed;
    
  int n = 2; /* number of parameters in model function f */
  double par[2] = {iParO.Ymax0, iParO.KD0}; /* starting values for the parameters to be fitted */
  int m = iParO.NP;   /* number of data points */

    
  double t[iParO.NP];  // = { 0.00, 0.20, 0.40, 0.60, 0.80, 1.00, 2.00, 3.00, 4.00 };
  double y[iParO.NP];  // = { 0.00, 0.08, 0.26, 0.24, 0.30, 0.25, 0.48, 0.50, 0.52 };
  double dy[iParO.NP];  // = { 0.10, 0.10, 0.30, 0.10, 0.25, 0.10, 0.10, 0.10, 0.10 };
  double PC[iParO.NP]; // = { 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50 };

  // progress
  std::cout << "working on: " << iParO.inp_file_kdi << "\n";
   
  //// read in inp_file_kdi
  std::ifstream inputFile (iParO.inp_file_kdi, std::ifstream::in);
  std::string lineInInputFile;
  
  if ( inputFile.is_open() )
  {
    //int lineNum = 0;
    int dataPointId = 0;
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100 
    std::cout << "------------------------------\n";
    //// get the column number of interest, the number of lines, and the number of segments in the longest filament
    while ( std::getline(inputFile, lineInInputFile) )
    {
      //lineNum = lineNum + 1;
      //std::cout << "lineNum: " << lineNum << "\n";
      
      //// split lines using the boost library
      std::vector<std::string> vectorContainingTheSplitLine;
      
      // use boost::split: any type of space, any number of space, any character
      //boost::split(vectorContainingTheSplitLine, lineInInputFile, boost::is_any_of("\t "),boost::token_compress_on );
        
          
      // use stream operator: any type of space, any number of space
      std::stringstream ss(lineInInputFile);
      while (ss.good()) {
          std::string word;
          ss >> word;
          vectorContainingTheSplitLine.push_back(word);
      }// while
          
          
      /*
      // use getline: any one character
      std::stringstream ss(lineInInputFile);
      while (ss.good()) {
             std::string word;
             getline(ss,word,'s');
             vectorContainingTheSplitLine.push_back(word);
      }
      */
        

      //// get column IDs
      if (vectorContainingTheSplitLine.size() >= 3 &&
          vectorContainingTheSplitLine[0]     == "_Data")
      {
  	    t[dataPointId]	 = std::stod(vectorContainingTheSplitLine[1]);  // concentration of the ligand
        y[dataPointId]   = std::stod(vectorContainingTheSplitLine[2]);  // physical measurement at this concentration of the ligand
        dy[dataPointId]  = std::stod(vectorContainingTheSplitLine[3]);  // physical measurement at this concentration of the ligand
        PC[dataPointId]  = iParO.PC; // protein concentration is the same for every time when the binding function is called
        dataPointId = dataPointId + 1;
      } // if
	} // while
    
    if (dataPointId != iParO.NP) {
        printf("The number of data points in the .kdi file and that in the .par file don't match! \n");
        exit(EXIT_FAILURE);
    } // if
      
    lm_control_struct control = lm_control_double;
    lm_status_struct status;
    control.verbosity = 9;

    printf( "Fitting ...\n" );
    /* now the call to lmfit */
    //lmcurve( n, par, m, t, y, f, &control, &status );
    lmcurve_tyd4( n, par, m, t, y, dy, PC, f_xyd4, &control, &status );
      
    printf( "Results:\n" );
    printf( "status after %d function evaluations:\n  %s\n",
              status.nfev, lm_infmsg[status.outcome] );

    printf("obtained parameters:\n");
    //for (int i = 0; i < n; ++i)
    //      printf("  par[%i] = %12g\n", i, par[i]);
    printf("  par[0] (Ymax) = %12g\n", par[0]);
    printf("  par[1] (KD  ) = %12g\n", par[1]);
      
    printf("obtained norm:\n  %12g\n", status.fnorm );

    printf("fitting data as follows:\n");
    for (int i = 0; i < m; ++i)
            printf(
            "  t[%1d]=%8.6f y=%8.6f+-%8.6f fit=%8.6f residue=%8.6f weighed=%8.6f\n",
            i, t[i], y[i], dy[i], f_xyd4(t[i],par,PC[i]), y[i] - f_xyd4(t[i],par,PC[i]), (y[i] - f_xyd4(t[i],par,PC[i]))/dy[i] );

      
      
      
    printf("Write the results into a .kdo file for plotting with Gnuplot:\n");
    std::ofstream outputFileKdo(iParO.out_file_kdo, std::ofstream::out);   // clean and write
    char sprintf_Data_X_Yoriginal_Ydeviation_Yfitted[100];
    std::stringstream lineInOutputSS;
    double xout = 0.00;
    for (int i = 0; i < m; ++i)
    {
      xout = t[i];
      sprintf(sprintf_Data_X_Yoriginal_Ydeviation_Yfitted, "%5s %6.5f %6.5f  %6.5f %6.5f", "_Data", xout, y[i], dy[i], f_xyd4out(par[0],par[1],PC[0],xout) );
      lineInOutputSS << sprintf_Data_X_Yoriginal_Ydeviation_Yfitted;
      outputFileKdo  << lineInOutputSS.str() << "\n";
      lineInOutputSS.str(std::string()); // empty the string stream
        
      for (int j = 1; j < iParO.Nip; ++j)
      {
        if (i < m-1) {
          xout = t[i] + (t[i+1] -t[i]) * j/iParO.Nip;
        } else if (i == m-1) {
          xout = t[i] + (t[i] -t[i-1]) * j/iParO.Nip;  // extropolate the fitted data
        } // if
        sprintf(sprintf_Data_X_Yoriginal_Ydeviation_Yfitted, "%5s %6.5f %6s %6s %6.5f", "_Data", xout, "-", "-", f_xyd4out(par[0],par[1],PC[0],xout) );
        lineInOutputSS << sprintf_Data_X_Yoriginal_Ydeviation_Yfitted;
        outputFileKdo  << lineInOutputSS.str() << "\n";
        lineInOutputSS.str(std::string()); // empty the string stream
      } // for j

    } // for i
      
      
    if (status.outcome<=3) {
          printf("SUCCESS\n");
    } else {
        printf("FAILURE\n");
    } // if
    
  } // if
}; // void
