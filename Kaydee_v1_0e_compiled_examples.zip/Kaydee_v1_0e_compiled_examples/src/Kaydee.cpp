// COMPILATION:            g++ -std=c++11 Program.cpp -o Program
// USAGE:                  ./Program
// EXAMPLE:                ./Program . dp6_ 4 101 1960 _autopick.star 2 82
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>

#include "KdFittingOneSiteXY.h"
#include "KdFittingOneSiteXYD.h"
#include "KdFittingOneSiteXYDF.h"

#include "TC_Parameters_Kaydee.h"
//#include "TF_ElapsedTime.h"
//#include "TC_StarToBox.h"
//#include "TF_ProgressBar.h"

//#include "TC_FileOpenAndFormatExceptions.h"
//#include "PctfSimulator.h"
//#include "PctfEstimator.h"

#include <iostream>
// Input and output stream; std::cout;

#include <string>
// String class; string object where the extracted line is stored.

//#include <boost/algorithm/string.hpp>
// Split algorithms are an extension to the find iterator for one common usage scenario. 
// These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 

#include <cstdlib>
// C Standard General Utilities Library; exit; fprintf

#include <iomanip>
// Input and output manipulation; including std::put_time (not in g++ --version 4.9 !!!), setfill, setw


int main(int argc, char *argv[]){

  std::cout << "*****************************************************************************************\n";


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//////// PRINTING USAGES
  if (argc < 2) {
    std::cout << 
    "USAGE:  \n"
    "      "<< argv[0] <<"   -parFile  kaydee.par > kaydee.log                                                            \n"
    "                                                                                       				              \n"
    "#### PARAMETER FILE                                                                                                  \n"
    "The parameter file is a plain .txt file containing one parameter per line.                                           \n"
    "Each line has a format of '_parName  parValue  # annotation of the parameter'                                        \n"
    "                                                                                       				              \n"
    "# EVERYTHING AFTER '#' IN THIS PAR FILE WILL BE IGNORED.                                                             \n"
    "# EVERY PARAMETER LINE IN THIS PAR FILE MUST HAVE '_' AT THE VERY BEGINNING.                                         \n"
    "# ALL THE PARAMETERS NEED TO BE PROVIDED; BUT NOT ALL OF THEM ARE USED IN A MODE.                                    \n"
    "                                                                                                                     \n"
    "# MODE                                                                                                               \n"
    "_mode                        1xy                     # string; 1xy; 1xyd, 1xydf                                      \n"
    "                                                                                                                     \n"
    "# INPUT file                                                                                                         \n"
    "_inp_data_kdi                kaydee_one_site_xy.kdi  # string; manually edited text file                             \n"
    "                                                                                                                     \n"
    "# OUTPUT file                                                                                                        \n"
    "_out_data_kdo                kaydee_one_site_xy.kdo  # string; text file                                             \n"
    "                                                                                                                     \n"
    "# DATA related parameters                                                                                            \n"
  //"_DT                          XY   # string;  data type: XY or XYD                                                    \n"
    "_NP                          9    # integer; number of data points                                                   \n"
    "_PC                          0.10 # double;  protein concentration in unit of uM                                     \n"
    "                                                                                                                     \n"
    "# FITTING related parameters                                                     								      \n"
    "_Ymax0                       1.00 # double;  starting maximum of y for fitting                                       \n"
    "_KD0                         1.00 # double;  starting dissociation constant for fitting                              \n"
    "_YmaxF                       0.55 # double;  only used in 1xydf mode; set it to a positive value to fix it during fitting \n"
    "_KDF                         0.00 # double;  only used in 1xydf mode; set it to a positive value to fix it during fitting \n"
    "                                                                                                                     \n"
    "# OUTPUT related parameters                                                                                          \n"
    "_Nip                         200  # integer; number of interpolated points between two experimental points, e.g., 20 \n"
    "		  															                                                  \n"
    "#### TERMINOLOGY													                        \n"
    "DT:    data type: XY or XYD                                                                \n"
    "NP:    number of data points, e.g., 9                                                      \n"
    "PC:    protein concentration, e.g. 1.00 uM                                                 \n"
    "X:     ligand concentration at one data point; e.g., 0.20 uM                               \n"
    "Y:     measurement change at one data point in an arbitrary unit, e.g., 10.00 degrees      \n"
    "D:     variation (standard deviation) of y at one data point; the weight of y              \n"
    "Ymax:  fitted maximum of y                                                                 \n"
    "KD:    fitted dissociation constant, e.g. 1.00 uM                                          \n"
    "Ymax0: starting maximum of y for fitting                                                   \n"
    "KD0:   starting dissociation constant for fitting                                          \n"
    "YmaxF: only used in 1xydf mode; set it to a positive value to fix Ymax during fitting      \n"
    "KDF:   only used in 1xydf mode; set it to a positive value to fix KD during fitting        \n"
    "Nip:   number of interpolated points between two experimental points, e.g., 20             \n"
    "															                      \n"
    "#### MODES 													                  \n"
    "1xy:   one binding site, without standard deviations in y values                 \n"
    "       IN:  kaydee_one_site_xy.par kaydee_one_site_xy.kdi                        \n"
    "       OUT: kaydee_one_site_xy.log kaydee_one_site_xy.kdo                        \n"
    "                                                                                 \n"
    "1xyd:  one binding site, with standard deviations (SDs) in y values              \n"
    "       If the SDs of all the data points in the .kdi file are the same positive value, mode 1xyd is equivalent to mode 1xy. \n"
    "       IN:  kaydee_one_site_xyd.par kaydee_one_site_xyd.kdi                      \n"
    "       OUT: kaydee_one_site_xyd.log kaydee_one_site_xyd.kdo                      \n"
    "                                                                                 \n"
    "1xydf: one binding site, with standard deviations in y values                    \n"
    "       In the .par file, use YmaxF to fix Ymax and KDF to fix KD during fitting. Fixing both causes failure during fitting. \n"
    "       If the SDs of all the data points in the .kdi file are the same positive value, mode 1xydf is equivalent to mode 1xyf, therefore not implemented. \n"
    "       IN:  kaydee_one_site_xydf.par kaydee_one_site_xydf.kdi                    \n"
    "       OUT: kaydee_one_site_xydf.log kaydee_one_site_xydf.kdo                    \n"
    "															     \n"
    "															     \n";
  std::cout << "=========================================================================================\n";
  exit(EXIT_FAILURE);    
  } // if  
  
  //// start time 
  //auto rawTimeStartURDS = std::chrono::system_clock::now(); 
   
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//////// READING PARAMETERS

  std::cout << ">>>> Reading parameters\n";  
  std::vector<std::string> argList;
  for(int i=1; i<argc; i++){argList.push_back(argv[i]);}
  Parameters parO(argList);
  std::cout << ">>>> Done reading parameters\n";  
  
  //// check parameters
  std::cout << ">>>> Checking parameters" << std::endl; 
  parO.checkParameters();
  std::cout << ">>>> Done checking parameters" << std::endl;
  std::cout << "-----------------------------------------------------------------------------------------\n";
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
  /*
  std::cout << ">>>> Running " << argv[0] << "\n"; 
  // Dynamic memory allocation and deallocation with 'new' and 'delete'
  // Dynamic memories remains there until either they are deallocated or program terminates.
  // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
  // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
  SmoothFilamentsInRunDataStar* newSmoothFilamentsInRunDataStarP = new SmoothFilamentsInRunDataStar(parO); 
  //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
  newSmoothFilamentsInRunDataStarP->smoothFilamentsInRunDataStar(); // = (*newPctfEstimatorP).run();	
  std::cout << ">>>> Done running " << argv[0] << "\n";     
  delete newSmoothFilamentsInRunDataStarP;  
  */
  if (parO.mode == "1xy"){
    std::cout << ">>>> Running " << argv[0] << " in mode: 1xy\n";
    // Dynamic memory allocation and deallocation with 'new' and 'delete'
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    KdFittingOneSiteXY* kdFittingOneSiteXY = new KdFittingOneSiteXY(parO);
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    kdFittingOneSiteXY->kdFittingOneSiteXY(); // = (*newPctfEstimatorP).run();

    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete kdFittingOneSiteXY;
  } else if (parO.mode == "1xyd"){
    std::cout << ">>>> Running " << argv[0] << " in mode: 1xyd\n";
    // Dynamic memory allocation and deallocation with 'new' and 'delete'
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
        
    KdFittingOneSiteXYD* kdFittingOneSiteXYD = new KdFittingOneSiteXYD(parO);
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();
    kdFittingOneSiteXYD->kdFittingOneSiteXYD(); // = (*newPctfEstimatorP).run();
    std::cout << ">>>> Done running " << argv[0] << "\n";
    delete kdFittingOneSiteXYD;
      
  } else if (parO.mode == "1xydf"){
      std::cout << ">>>> Running " << argv[0] << " in mode: 1xydf\n";
      // Dynamic memory allocation and deallocation with 'new' and 'delete'
      // Dynamic memories remains there until either they are deallocated or program terminates.
      // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
      // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
          
      KdFittingOneSiteXYDF* kdFittingOneSiteXYDF = new KdFittingOneSiteXYDF(parO);
      //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();
      kdFittingOneSiteXYDF->kdFittingOneSiteXYDF(); // = (*newPctfEstimatorP).run();
      std::cout << ">>>> Done running " << argv[0] << "\n";
      delete kdFittingOneSiteXYDF;
        
    }
  //// calculateElapsedTime
  //std::cout << calculateElapsedTime(rawTimeStartURDS) << "\n"; 
  std::cout << "=========================================================================================\n"; 
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100


} // main
