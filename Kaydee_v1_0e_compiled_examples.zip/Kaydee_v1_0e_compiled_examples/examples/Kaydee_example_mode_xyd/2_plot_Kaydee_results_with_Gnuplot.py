#!/usr/bin/python
#
# AUTHOR: Steven Chou 
# (stevenzchou@gmail.com)
#
#
#



########################################################################
# References
'''

'''



########################################################################
# Import modules


import sys, re, string, os, os.path, math, platform, commands
# re: regular expression


########################################################################
# Usage

if (len(sys.argv) != 3 and len(sys.argv) != 1):
  print '''
  Usage:''', sys.argv[0], ''' kaydee.log  kaydee.kdo
  Notes:
         kaydee.log   the .log file from Kaydee; default: kaydee_one_site_xy_4.log
         kaydee.kdo   the .kdo file from Kaydee; default: kaydee_one_site_xy_3.kdo
         
  INP: 'kaydee.log' and 'kaydee.kdo'.
  OUT: 'kaydee.scr' and 'kaydee.ps'.
  
  If the .ps file is not perfect using the default parameters,
  edit kaydee.scr manually with a text editor and run Gnuplot again.
  nedit kaydee.scr &
  gnuplot kaydee.scr\n'''
  
  sys.exit()
 
########################################################################
# I/O files

if len(sys.argv) == 3:
  kaydee_log     = sys.argv[1]
  kaydee_kdo     = sys.argv[2]
    
if len(sys.argv) == 1:
  if os.path.isfile("kaydee_one_site_xy_4.log") and os.access("kaydee_one_site_xy_4.log", os.R_OK) and \
     os.path.isfile("kaydee_one_site_xy_3.kdo") and os.access("kaydee_one_site_xy_3.kdo", os.R_OK):
    kaydee_log     = "kaydee_one_site_xy_4.log"
    kaydee_kdo     = "kaydee_one_site_xy_3.kdo"
  
  elif os.path.isfile("kaydee_one_site_xyd_4.log") and os.access("kaydee_one_site_xyd_4.log", os.R_OK) and\
       os.path.isfile("kaydee_one_site_xyd_3.kdo") and os.access("kaydee_one_site_xyd_3.kdo", os.R_OK):

    kaydee_log     = "kaydee_one_site_xyd_4.log"
    kaydee_kdo     = "kaydee_one_site_xyd_3.kdo"
  
  elif os.path.isfile("kaydee_one_site_xydf_4.log") and os.access("kaydee_one_site_xydf_4.log", os.R_OK) and\
       os.path.isfile("kaydee_one_site_xydf_3.kdo") and os.access("kaydee_one_site_xydf_3.kdo", os.R_OK):
    kaydee_log     = "kaydee_one_site_xydf_4.log"
    kaydee_kdo     = "kaydee_one_site_xydf_3.kdo"
    
  '''
  kaydee_log_basename = os.path.basename(kaydee_log)
  kaydee_log_basename_array = re.split(r'4.log', kaydee_log_basename)
  kaydee_scr = kaydee_log_basename_array[0]+"5.scr"
  kaydee_ps  = kaydee_log_basename_array[0]+"6.ps"
  '''
  
kaydee_log_basename = os.path.basename(kaydee_log)
kaydee_log_basename_array = re.split(r'.log', kaydee_log_basename)
if kaydee_log_basename_array[0].endswith("4"):
  kaydee_log_basename_array0m1 = kaydee_log_basename_array[0].rstrip(kaydee_log_basename_array[0][-1])
  kaydee_scr = kaydee_log_basename_array0m1+"5.scr"
  kaydee_ps  = kaydee_log_basename_array0m1+"6.ps"
else:
  kaydee_scr = kaydee_log_basename_array[0]+"5.scr"
  kaydee_ps  = kaydee_log_basename_array[0]+"6.ps"

##############################
# print out the input parameters
print                 "============================================================================================"
print                 "%s%s"     %  ("_kaydee_log          = ", kaydee_log)
print                 "%s%s"     %  ("_kaydee_kdo          = ", kaydee_kdo)
print                 "%s%s"     %  ("_kaydee_scr          = ", kaydee_scr)
print                 "%s%s"     %  ("_kaydee_ps           = ", kaydee_ps)
print                 "============================================================================================"


# Parameters to be read from the log file:
# FittingResult: ?FittingResult?; DataType: ?DataType?; Ymax ?YmaxValue? (?YmaxFittedOrFixed?); Kd: ?KdValue? (?KdFittedOrFixed?)
# Parameters to be read from the kdo file:
# xLo; xHi; yLo; yHi

##############################
# do the calculations



########
	
if os.path.isfile(kaydee_log) and os.access(kaydee_log, os.R_OK) and os.path.isfile(kaydee_kdo) and os.access(kaydee_kdo, os.R_OK):

    #### kaydee_log file
    filehandle_inp_kaydee_log	  = open(kaydee_log, "r")
    
    FittingResult     = ""
    DataType          = ""
    #PC                = 0.00
    PC                = ""
    YmaxValue         = 0.00
    YmaxFittedOrFixed = ""
    KdValue           = 0.00
    KdFittedOrFixed   = ""

    while True :
      line_kaydee_log = filehandle_inp_kaydee_log.readline()

      if len(line_kaydee_log) == 0:	   ## In fact, blank lines are "\n".
	    break
      line_kaydee_log = line_kaydee_log.rstrip('\n')     ## remove "\n"
      array_kaydee_log = re.split(r'\s+', line_kaydee_log)
      #print array_kaydee_log
      
      if len(array_kaydee_log)>=1 and array_kaydee_log[0] == "SUCCESS":
        FittingResult      = "Successful"
      if len(array_kaydee_log)>=1 and array_kaydee_log[0] == "FAILURE":
        FittingResult      = "Failed"
      

      if len(array_kaydee_log)>=3 and array_kaydee_log[0] == "mode" and array_kaydee_log[2] == "1xy":
        DataType           = "XY"
      if len(array_kaydee_log)>=3 and array_kaydee_log[0] == "mode" and array_kaydee_log[2] == "1xyd":
        DataType           = "XYD"
      if len(array_kaydee_log)>=3 and array_kaydee_log[0] == "mode" and array_kaydee_log[2] == "1xydf":
        DataType           = "XYDF"
        
        
      if len(array_kaydee_log)>=3 and array_kaydee_log[0] == "PC":
        #PC                 = float(array_kaydee_log[2])
        PC                 = array_kaydee_log[2]
        
      if len(array_kaydee_log)>=3 and array_kaydee_log[1] == "par[0]" and array_kaydee_log[2] == "(Ymax)":
        YmaxValue          = float(array_kaydee_log[4])
        
        
      if   len(array_kaydee_log)>=3 and array_kaydee_log[0] == "YmaxF" and float(array_kaydee_log[2]) >  0.00 and DataType == "XYDF":
        YmaxFittedOrFixed  = "Fixed"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "YmaxF" and float(array_kaydee_log[2]) <= 0.00 and DataType == "XYDF":
        YmaxFittedOrFixed  = "Fitted"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "YmaxF" and DataType == "XYD":
        YmaxFittedOrFixed  = "Fitted"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "YmaxF" and DataType == "XY":
        YmaxFittedOrFixed  = "Fitted"
      
      if len(array_kaydee_log)>=3 and array_kaydee_log[1] == "par[1]" and array_kaydee_log[2] == "(KD" :
        KdValue            = float(array_kaydee_log[5])
        
      if   len(array_kaydee_log)>=3 and array_kaydee_log[0] == "KDF" and float(array_kaydee_log[2]) >  0.00 and DataType == "XYDF" :
        KdFittedOrFixed  = "Fixed"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "KDF" and float(array_kaydee_log[2]) <= 0.00 and DataType == "XYDF":
        KdFittedOrFixed  = "Fitted"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "KDF" and DataType == "XYD":
        KdFittedOrFixed  = "Fitted"
      elif len(array_kaydee_log)>=3 and array_kaydee_log[0] == "KDF" and DataType == "XY":
        KdFittedOrFixed  = "Fitted"
    filehandle_inp_kaydee_log.close()
    
    '''
    print FittingResult
    print DataType
    print PC
    print YmaxValue
    print YmaxFittedOrFixed
    print KdValue
    print KdFittedOrFixed
    '''
    
    
    #### kaydee_kdo file
    filehandle_inp_kaydee_kdo	  = open(kaydee_kdo, "r")
    
    xLo   = 0.00
    xHi   = 0.00
    yLo   = 0.00
    yHi   = 0.00
    
    
    while True :
      line_kaydee_kdo = filehandle_inp_kaydee_kdo.readline()

      if len(line_kaydee_kdo) == 0:	   ## In fact, blank lines are "\n".
	    break
      line_kaydee_kdo = line_kaydee_kdo.rstrip('\n')     ## remove "\n"
      array_kaydee_kdo = re.split(r'\s+', line_kaydee_kdo)

      #print array_kaydee_kdo
      if len(array_kaydee_kdo)>=4 and array_kaydee_kdo[0] == "_Data":
        #print array_kaydee_kdo[1], array_kaydee_kdo[2]
        data_x = float(array_kaydee_kdo[1])
        if data_x < xLo: xLo = data_x
        if data_x > xHi: xHi = data_x
        if array_kaydee_kdo[2] != "-":
          #print array_kaydee_kdo[1], array_kaydee_kdo[2]
          #print float(array_kaydee_kdo[1]), float(array_kaydee_kdo[2])
          data_y = float(array_kaydee_kdo[2])
          if data_y < yLo: yLo = data_y
          if data_y > yHi: yHi = data_y

    filehandle_inp_kaydee_kdo.close()
    
    '''
    print xLo
    print xHi
    print yLo
    print yHi
    '''
    
    #### kaydee_scr file
    filehandle_out_kaydee_scr     = open(kaydee_scr, "w")

    if (DataType == "XY"):
      filehandle_out_kaydee_scr.write( '''
      set terminal postscript  enhanced color colortext solid linewidth 2 size 10 ,7 rounded 'Times-Roman' 22
      set output '%s'
      #set encoding iso_8859_1;
      set title 'Fitting: %s; DataType: %s; PC: %s; Ymax: %f (%s); Kd: %f (%s)' font 'Courier,11' tc lt 3
      set size  1,1
      set xlabel  '[Ligand]/{/Symbol mM}' font 'Times-Roman,20' textcolor lt 0
      set xrange [%f:%f]
      #set xtics 0,20,180 font ',22'
      #set mxtics 2
      #### FSC [Green]
      set ylabel  'Measurement Change (AU)' font 'Times-Roman,20' textcolor lt 0
      set yrange [%f:%f]
      #set ytics 0.0,0.1,1.0
      #set ytics 0.00,0.02,0.20 nomirror   textcolor rgb 'green'
      #set mytics 2\n\
      #set arrow 1 from first 0, 0.143 to first 0.5, 0.143 nohead linewidth 0.5 linetype 2
      #set object 1 circle at first xxx,xxx radius char 0.25 fillcolor lt 2 fillstyle solid
      #### Resolution [Red]
      #set y2label  'Resolution Limit (\305)' font 'Times-Roman,20' textcolor lt 1
      #set y2range [-0.1:1.1]
      #set y2tics 0.0,0.1,1.0 nomirror     textcolor rgb 'red'
      #set my2tics 2
      #set arrow 2 from second 0, 4.0 to second 180, 4.0 nohead linewidth 0.5 linetype 1
      #set object 2 circle at second xxx,xxx radius char 0.25 fillcolor lt 1 fillstyle solid
      set key off
      set bars small
      set multiplot
      #plot 'xxx' using 1:2 with lines axes x1y1 linewidth 1 lt 2, 'xxx' using 1:3 with lines axes x1y2 linewidth 1 lt 1
      plot  '%s' using 2:4 with lines   linetype  2 linewidth 3   linecolor rgb 'red'   axes x1y1
      plot  '%s' using 2:3 with points  pointtype 7 pointsize 1.5 linecolor rgb 'black'
      unset multiplot
      set output
      set terminal pop''' % (kaydee_ps,FittingResult,DataType,PC,YmaxValue,YmaxFittedOrFixed,KdValue,KdFittedOrFixed,xLo,xHi,yLo,YmaxValue,kaydee_kdo,kaydee_kdo) )

    if (DataType == "XYD" or DataType == "XYDF" ):
      filehandle_out_kaydee_scr.write( '''
      set terminal postscript  enhanced color colortext solid linewidth 2 size 10 ,7 rounded 'Times-Roman' 22
      set output '%s'
      #set encoding iso_8859_1;
      set title 'Fitting: %s; DataType: %s; PC: %s; Ymax: %f (%s); Kd: %f (%s)' font 'Courier,11' tc lt 3
      set size  1,1
      set xlabel  '[Ligand]/{/Symbol mM}' font 'Times-Roman,20' textcolor lt 0
      set xrange [%f:%f]
      #set xtics 0,20,180 font ',22'
      #set mxtics 2
      #### FSC [Green]
      set ylabel  'Measurement Change (AU)' font 'Times-Roman,20' textcolor lt 0
      set yrange [%f:%f]
      #set ytics 0.0,0.1,1.0
      #set ytics 0.00,0.02,0.20 nomirror   textcolor rgb 'green'
      #set mytics 2\n\
      #set arrow 1 from first 0, 0.143 to first 0.5, 0.143 nohead linewidth 0.5 linetype 2
      #set object 1 circle at first xxx,xxx radius char 0.25 fillcolor lt 2 fillstyle solid
      #### Resolution [Red]
      #set y2label  'Resolution Limit (\305)' font 'Times-Roman,20' textcolor lt 1
      #set y2range [-0.1:1.1]
      #set y2tics 0.0,0.1,1.0 nomirror     textcolor rgb 'red'
      #set my2tics 2
      #set arrow 2 from second 0, 4.0 to second 180, 4.0 nohead linewidth 0.5 linetype 1
      #set object 2 circle at second xxx,xxx radius char 0.25 fillcolor lt 1 fillstyle solid
      set key off
      set bars small
      set multiplot
      plot  '%s' using 2:5 with lines   linetype  2 linewidth 3   linecolor rgb 'red'   axes x1y1
      set bars 2
      #plot  'xxx' using 2:3:4 with yerrorbars   pointtype 3 pointsize 1.5 linecolor rgb 'black'
      plot  '%s' using 2:3:4 with yerrorbars   pointtype 6 pointsize 1.5 linecolor rgb 'black'
      unset multiplot
      set output
      set terminal pop''' % (kaydee_ps,FittingResult,DataType,PC,YmaxValue,YmaxFittedOrFixed,KdValue,KdFittedOrFixed,xLo,xHi,yLo,YmaxValue,kaydee_kdo,kaydee_kdo) )

    filehandle_out_kaydee_scr.close()
    	    
    #### OUTPUT: .ps
    os.system( "%s%s" % ("rm -rf ", kaydee_ps) )
    
    status,output=commands.getstatusoutput("which gnuplot")
    if (output != ""):
        os.system( "%s%s" % ("gnuplot ", kaydee_scr) )
        print "Please check the output file: %s! " % (kaydee_ps)
    else:
        print "Gnuplot is not found on your system. Please install Gnuplot first."

    
    if (platform.system() == "Darwin"):
        os.system("%s%s" % ("open ",  kaydee_ps ) )
    if (platform.system() == "Linux"):
        os.system("%s%s" % ("display ",  kaydee_ps ) )
        # convert it to .pdf file
        os.system("%s%s" % ("ps2pdf ",   kaydee_ps ) )
        #os.system("%s%s" % ("display ",  kaydee_pdf ) )
    
else:
    print "THE FOLLOWING TWO FILES ARE EITHER MISSING OR NOT READABLE!", kaydee_log, kaydee_kdo



########################################################################
# Closing more files

print "DONE running the script!"
print "============================================================================================"
print '''
  If the .ps file is not perfect using the default parameters,
  edit kaydee.scr manually with a text editor and run Gnuplot again.
  nedit kaydee.scr &
  gnuplot kaydee.scr\n'''
exit(0)
